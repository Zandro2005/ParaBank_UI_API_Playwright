import { Locator, Page } from '@playwright/test';

export class AccountsPage {
    readonly page: Page;
    readonly overviewTable: Locator;
    readonly accountRows: Locator;
    readonly balanceCells: Locator;
    readonly totalRow: Locator;
    readonly totalBalanceCell: Locator;
    readonly accountColumnHeader: Locator;
    readonly balanceColumnHeader: Locator;
    readonly availableAmountColumnHeader: Locator;
    readonly openNewAccountBtn: Locator;
    readonly accountType: Locator;
    readonly accountId: Locator;
    readonly accountHeading: Locator;
    

    constructor(page: Page) {
        this.page = page;
        this.overviewTable = page.locator('#accountTable');
        this.accountRows = page.locator('#accountTable tbody tr').filter({ has: page.locator('td a') });
        this.balanceCells = this.accountRows.locator('td:nth-child(2)');
        this.totalRow = page.locator('#accountTable tbody tr').filter({ hasText: 'Total' });
        this.totalBalanceCell = this.totalRow.locator('td:nth-child(2)');
        this.accountColumnHeader = page.getByRole('columnheader', { name: 'Account' });
        this.balanceColumnHeader = page.getByRole('columnheader', { name: 'Balance' });
        this.availableAmountColumnHeader = page.getByRole('columnheader', { name: 'Available Amount' });
        this.openNewAccountBtn = page.getByRole('link', {name:'Open New Account'});
        this.accountHeading = page.getByRole('heading', {name: 'Account Opened!'});
        this.accountType = page.locator('#type');
        this.accountId = page.locator('#fromAccountId');
        

    }

    async navigate(): Promise<void> {
        await this.page.goto('overview.htm');
        await this.overviewTable.waitFor({ state: 'visible' });
    }

    async getAccountBalances(): Promise<number[]> {
        await this.accountRows.first().waitFor({ state: 'visible' });
        const texts = await this.balanceCells.allInnerTexts();
        return texts.map(text => this.parseCurrency(text));
    }

    async getTotalBalance(): Promise<number> {
        await this.totalBalanceCell.waitFor({ state: 'visible' });
        const text = await this.totalBalanceCell.innerText();
        return this.parseCurrency(text);
    }

    parseCurrency(value: string): number {
        return parseFloat(value.replace(/[^0-9.-]+/g, ''));
    }

    async clickOpenNewAccountLink(): Promise<void>{
        await this.openNewAccountBtn.click();

    }

    async selectAccountType(): Promise<void>{
        await this.accountType.selectOption('CHECKING');

    }

    async selectAccountId(): Promise<void>{
        await this.accountId.selectOption('123456')

    }

    async clickOpenNewAccountBtn(): Promise<void>{
        await this.openNewAccountBtn.click();

    }

}

