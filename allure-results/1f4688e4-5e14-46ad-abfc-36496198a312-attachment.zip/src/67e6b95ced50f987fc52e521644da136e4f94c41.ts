import {test, expect} from '@playwright/test'
import { AccountApi } from '@api/AccountApi'

test('Fetch accountsfor customer', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    
    expect(response.status()).toBe(200);
    
});

test('Validate account schema & data types', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    const responsebody = await response.json();

    expect(response.status()).toBe(200);
    expect(responsebody[0].id).toBeDefined();
    expect(responsebody[0].customerId).toBeDefined();
    expect(responsebody[0].type).toBeDefined();
    expect(responsebody[0].balance).toBeDefined();

});

test('Get account details by ID', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getAccount(13344);
    const responsebody = await response.json()
    const requestId = responsebody.id;

    expect(response.status()).toBe(200);
    expect(responsebody.id).toEqual(requestId);
    

});

test('Verify customer account ownership', async({request}) =>{
    const accountApi = new AccountApi(request)
    const customerID = 12212; 
    const response = await accountApi.getCustomerAccounts(customerID);
    const responsebody = await response.json();

    expect(response.status()).toBe(200);
    expect(customerID).toEqual(responsebody[0].customerId);

});