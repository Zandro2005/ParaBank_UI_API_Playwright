import {test, expect} from '@playwright/test';
import { AuthAPI } from '@api/AuthApi';

test('Authenticate with valid credentials', async({request}) =>{
    const authApi = new AuthAPI(request);
    const response = await authApi.login(process.env.TEST_USERNAME!, process.env.TEST_PASSWORD!);

    const responseBody = await response.json();
    console.log(responseBody)

    expect(response.status()).toBe(200);
    expect(responseBody.id).toEqual(12212);
    expect(responseBody.firstName).toBe('John');
    expect(responseBody.address.state).toBe('CA');

});

test('Validate login JSON response schema', async({request}) =>{
    const authApi = new AuthAPI(request);
    const response = await authApi.login(process.env.TEST_USERNAME!, process.env.TEST_PASSWORD!);
    const responseBody = await response.json();
    
    expect(response.status()).toBe(200);
    expect(responseBody.id).toBeDefined();
    expect(responseBody.firstName).toBeDefined();
    expect(responseBody.lastName).toBeDefined();
    expect(responseBody.address).toBeDefined();
    expect(responseBody.phoneNumber).toBeDefined();
    expect(responseBody.ssn).toBeDefined();

});

test('Validate response headers', async({request}) =>{
    const response = await request.get('')

});