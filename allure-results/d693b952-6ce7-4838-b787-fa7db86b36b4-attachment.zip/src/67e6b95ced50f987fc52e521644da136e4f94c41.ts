import {test, expect} from '@playwright/test';
import { AuthApi } from '@api/AuthApi';

test('Authenticate with valid credentials', async({request}) =>{
    const authApi = new AuthApi(request);
    const response = await authApi.login(process.env.TEST_USERNAME!, process.env.TEST_PASSWORD!);

    const responseBody = await response.json();
    console.log(responseBody)

    expect(response.status()).toBe(200);
    expect(responseBody.id).toEqual(12212);
    expect(responseBody.firstName).toBe('John');
    expect(responseBody.address.state).toBe('CA');

});

test('Validate login JSON response schema', async({request}) =>{
    const authApi = new AuthApi(request);
    const response = await authApi.login(process.env.TEST_USERNAME!, process.env.TEST_PASSWORD!);
    const responseBody = await response.json();
    
    expect(response.status()).toBe(200);
    expect(responseBody.id).toBeDefined();
    expect(responseBody.firstName).toBeDefined();
    expect(responseBody.lastName).toBeDefined();
    expect(responseBody.address).toBeDefined();
    expect(responseBody.phoneNumber).toBeDefined();
    expect(responseBody.ssn).toBeDefined();

});

test('Validate response headers', async({request}) =>{
    const authApi = new AuthApi(request);
    const response = await authApi.login(process.env.TEST_USERNAME!, process.env.TEST_PASSWORD!);

    const headers = response.headers();

    expect(headers['content-type']).toContain('application/json')

});

test('Content negotiation for XML', async({request}) =>{
    const authApi = new AuthApi(request);
    const response = await authApi.login('john', 'demo', 'appilication/xml');

    expect(response.status()).toBe(200);

    const responseHeader = await response.headers()['content-type'];
    
    expect(responseHeader).toContain('xml');

    const xmlBody = await response.text();

    expect(xmlBody).toContain('<customer>');
    expect(xmlBody).toContain('</customer>');
    expect(xmlBody).toContain('<id>12212</id>');

});

test('Login response latency SLA', async({request}) =>{
    const authApi = new AuthApi(request);
    const startTime = performance.now();
    const response = await authApi.login('john', 'demo');

    expect(response.status()).toBe(200);
    
    const duration = performance.now() - startTime

    expect(duration).toBeLessThan(2000);

});


