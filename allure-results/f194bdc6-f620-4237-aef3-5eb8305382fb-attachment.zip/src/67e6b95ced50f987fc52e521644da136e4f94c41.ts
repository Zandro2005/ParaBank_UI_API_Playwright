import {test, expect} from '@playwright/test';

test('Authenticate with valid credentials', async({request}) =>{
    const response = await request.get('https://parabank.parasoft.com/parabank/services/bank/login/john/demo', {
        headers: {
            'Accept': 'application/json'
        }  

    });

    const responseBody = await response.json();

    await expect(response.status()).toBe(200);
    console.log(responseBody)

});