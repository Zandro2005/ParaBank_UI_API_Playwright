import {APIRequestContext, APIResponse} from '@playwright/test'

export class AuthAPI{
    constructor(private request: APIRequestContext){}

    async login(username: string, password: string): Promise<APIResponse>{
        return await
        this.request.get('https://parabank.parasoft.com/parabank/services/bank/login/john/demo', {
            headers:{
                'Accept': 'application/json'
            }

        });

    }

}