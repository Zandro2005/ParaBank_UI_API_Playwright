import { APIRequestContext, APIResponse } from '@playwright/test';

export interface Transaction {
    id: number;
    accountId: number;
    type: 'Credit' | 'Debit';
    date: number;
    amount: number;
    description: string;
}

export class TransactionApi {
    readonly baseUrl = 'https://parabank.parasoft.com/parabank/services/bank';

    constructor(private request: APIRequestContext) {}

    /**
     * GET /accounts/{accountId}/transactions
     * Retrieves all transactions associated with an account.
     */
    async getAccountTransactions(accountId: number | string): Promise<APIResponse> {
        return await this.request.get(`${this.baseUrl}/accounts/${accountId}/transactions`, {
            headers: { 'Accept': 'application/json' },
        });
    }

    /**
     * GET /transactions/{transactionId}
     * Retrieves details for a specific transaction by its ID.
     */
    async getTransaction(transactionId: number | string): Promise<APIResponse> {
        return await this.request.get(`${this.baseUrl}/transactions/${transactionId}`, {
            headers: { 'Accept': 'application/json' },
        });
    }
}
