import {test, expect} from '@playwright/test'
import { AccountApi } from '@api/AccountApi'
import { AuthApi } from '@api/AuthApi';

test('Fetch accountsfor customer', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    
    expect(response.status()).toBe(200);
    
});

test('Validate account schema & data types', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    const responsebody = await response.json();

    expect(response.status()).toBe(200);
    expect(responsebody[0].id).toBeDefined();
    expect(responsebody[0].customerId).toBeDefined();
    expect(responsebody[0].type).toBeDefined();
    expect(responsebody[0].balance).toBeDefined();

});

test('Get account details by ID', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getAccount(13344);
    const responsebody = await response.json()
    const requestId = responsebody.id;

    expect(response.status()).toBe(200);
    expect(responsebody.id).toEqual(requestId);
    

});

test('Verify customer account ownership', async({request}) =>{
    const accountApi = new AccountApi(request)
    const customerID = 12212; 
    const response = await accountApi.getCustomerAccounts(customerID);
    const responsebody = await response.json();

    expect(response.status()).toBe(200);
    expect(customerID).toEqual(responsebody[0].customerId);

});

test('Create CHECKING account via API', async({request}) =>{
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const accountType = 0;
    const accountId = 13344;
    const response = await accountApi.createAccount(customerId, accountType, accountId);
    const responsebody = await response.json()

    expect(response.status()).toBe(200);
    expect(responsebody.type).toBe('CHECKING');

});

test('Create SAVINGS account via API', async({request}) =>{
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const accountType = 1;
    const accountId = 13344;
    const response = await accountApi.createAccount(customerId, accountType, accountId);
    const responsebody = await response.json()

    expect(response.status()).toBe(200);
    expect(responsebody.type).toBe('SAVINGS');
    
});

test('Minimum opening deposit debit/credit', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const sourceAccountId = 13344;

    const initialSourceRes = await accountApi.getAccount(sourceAccountId);
    const initialBalance = (await initialSourceRes.json()).balance;

    const createRes = await accountApi.createAccount(customerId, 0, sourceAccountId);
    expect(createRes.status()).toBe(200);
    const createdAccount = await createRes.json();
    const newAccountId = createdAccount.id;

    const updatedSourceRes = await accountApi.getAccount(sourceAccountId);
    const updatedSourceBalance = (await updatedSourceRes.json()).balance;
    const newAccountRes = await accountApi.getAccount(newAccountId);
    const newAccountBalance = (await newAccountRes.json()).balance;

    expect(Math.abs(updatedSourceBalance - initialBalance)).toBe(100.00);

    expect(Math.abs(newAccountBalance)).toBe(100.00);
});

test('Newly created account in list', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const sourceAccountId = 13344;

    // 1. Create a new account (0 = CHECKING)
    const createRes = await accountApi.createAccount(customerId, 0, sourceAccountId);
    expect(createRes.status()).toBe(200);
    const newAccount = await createRes.json();
    const newAccountId = newAccount.id;

    // 2. Fetch all accounts for this customer: GET /customers/{id}/accounts
    const accountsRes = await accountApi.getCustomerAccounts(customerId);
    expect(accountsRes.status()).toBe(200);
    const accounts = await accountsRes.json();

    // 3. Verify new account ID is present in the customer's account list
    const isPresent = accounts.some((account: { id: number }) => account.id === newAccountId);
    expect(isPresent).toBe(true);
});

test('TC-ACC-API-009 Balance decimal precision', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const response = await accountApi.getAccount(13344);

    expect(response.status()).toBe(200);
    const account = await response.json();
    expect(account.balance).toBeDefined();

    // Balance should have at most 2 decimal places (balance * 100 rounded has zero remainder)
    const decimals = account.balance.toString().split('.')[1]?.length || 0;
    expect(decimals).toBeLessThanOrEqual(2);
});

test('TC-ACC-API-010 Get non-existent account ID', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const response = await accountApi.getAccount(999999999);

    expect([400, 404]).toContain(response.status());
    const errorBody = await response.text();
    expect(errorBody).toContain('Could not find account #999999999');
});

test('TC-ACC-API-011 Get account with non-numeric ID', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const response = await accountApi.getAccount('invalid_id');

    expect([400, 404]).toContain(response.status());
});

test('TC-ACC-API-012 Get accounts for non-existent customer', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(999999999);

    expect([400, 404]).toContain(response.status());
});

test('TC-ACC-API-013 Create account with invalid type code', async ({ request }) => {
    const accountApi = new AccountApi(request);
    // Invalid type code 99 (valid: 0 = CHECKING, 1 = SAVINGS)
    const response = await accountApi.createAccount(12212, 99, 13344);

    expect([400, 500]).toContain(response.status());
});

test('TC-ACC-API-014 Create account missing parameters', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const response = await accountApi.createAccount();

    expect([400, 500]).toContain(response.status());
});

test('TC-ACC-API-015 Create account using another user\'s funds', async ({ request }) => {
    const accountApi = new AccountApi(request);
    // Customer 12212 attempts to create an account using another user's account ID (999999999)
    const response = await accountApi.createAccount(12212, 0, 999999999);

    if (response.status() === 200) {
        test.info().annotations.push({
            type: 'known-defect',
            description: 'AUT accepts createAccount using unverified / foreign fromAccountId funds.'
        });
    }

    expect([400, 403, 404, 200]).toContain(response.status());
});

test('TC-ACC-API-016 Unauthorized accounts request', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);

    // Standard banking expectation is 401 Unauthorized.
    // Document deviation as @known-defect since ParaBank REST demo is open.
    if (response.status() === 200) {
        test.info().annotations.push({
            type: 'known-defect',
            description: 'ParaBank REST API does not enforce session or authentication token verification.'
        });
    }

    expect([401, 200]).toContain(response.status());
});

test('TC-ACC-API-017 Accounts API response headers & SLA', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const startTime = performance.now();
    const response = await accountApi.getAccount(13344);
    const duration = performance.now() - startTime;

    expect(response.status()).toBe(200);
    expect(response.headers()['content-type']).toContain('application/json');
    expect(duration).toBeLessThan(2000);
});

test('TC-LOAN-API-001 Request loan – approved API', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const response = await accountApi.requestLoan(12212, 500, 50, 13344);

    expect(response.status()).toBe(200);
    const loanData = await response.json();
    expect(loanData.approved).toBe(true);
    expect(loanData.accountId).toBeDefined();
});

test('TC-LOAN-API-002 Request loan – denied API', async ({ request }) => {
    const accountApi = new AccountApi(request);
    // Request a loan with down payment far exceeding available funds
    const response = await accountApi.requestLoan(12212, 10000000, 9000000, 13344);

    expect(response.status()).toBe(200);
    const loanData = await response.json();
    expect(loanData.approved).toBe(false);
});



