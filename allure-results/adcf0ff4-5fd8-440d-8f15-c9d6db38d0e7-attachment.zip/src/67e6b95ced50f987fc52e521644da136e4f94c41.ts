import {test, expect} from '@playwright/test'
import { AccountApi } from '@api/AccountApi'

test('Fetch accountsfor customer', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    
    expect(response.status()).toBe(200);
    

});