import { test, expect } from '@fixtures/authFixture';
import { AccountsPage } from '@pages/AccountsPage';

test.describe('Accounts Overview UI', () => {

    test('TC-ACC-UI-001 View Accounts Overview table', async ({ loginPage, page }) => {
        const accountsPage = new AccountsPage(page);

        await expect(accountsPage.accountColumnHeader).toBeVisible();
        await expect(accountsPage.balanceColumnHeader).toBeVisible();
        await expect(accountsPage.availableAmountColumnHeader).toBeVisible();
        await expect(accountsPage.totalRow).toBeVisible();
    });

    test('TC-ACC-UI-002 Verify Total equals sum of balances', async ({ loginPage, page }) => {
        const accountsPage = new AccountsPage(page);

        // 1) Parse all balance column values
        const balances = await accountsPage.getAccountBalances();
        expect(balances.length).toBeGreaterThanOrEqual(1);

        // 2) Sum mathematically
        const calculatedSum = balances.reduce((sum, val) => sum + val, 0);

        // 3) Read Total row
        const reportedTotal = await accountsPage.getTotalBalance();

        // Total matches sum of all individual balances within $0.01
        expect(reportedTotal).toBeCloseTo(calculatedSum, 2);
    });

    test('TC-ACC-UI-003 Balance currency formatting', async ({ loginPage, page }) => {
        const accountsPage = new AccountsPage(page);
        const currencyRegex = /^-?\$[\d,]+\.\d{2}$/;

        // 1) Wait for accounts table to finish loading
        await accountsPage.accountRows.first().waitFor({ state: 'visible' });

        // 2) Inspect all individual balance values in the table
        const balances = await accountsPage.balanceCells.allInnerTexts();
        expect(balances.length).toBeGreaterThanOrEqual(1);

        for (const balance of balances) {
            expect(balance.trim()).toMatch(currencyRegex);
        }

        // 3) Inspect Total balance row format
        const totalBalance = await accountsPage.totalBalanceCell.innerText();
        expect(totalBalance.trim()).toMatch(currencyRegex);
    });

    test('TC-ACC-UI-004 Open new CHECKING account', async ({ loginPage, page }) => {
        const accountPage = new AccountsPage(page);

        await accountPage.clickOpenNewAccountLink();
        await accountPage.selectAccountType('CHECKING');
        await accountPage.selectAccountId(0);
        await accountPage.clickOpenNewAccountBtn();

        await expect(accountPage.accountHeading).toBeVisible();
        await expect(accountPage.newAccountIdLink).toBeVisible();
    });

});
