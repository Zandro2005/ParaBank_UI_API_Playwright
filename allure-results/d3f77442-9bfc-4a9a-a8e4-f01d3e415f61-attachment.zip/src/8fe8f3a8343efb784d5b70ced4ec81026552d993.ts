import { test, expect } from '@fixtures/authFixture';
import { ProfilePage } from '@pages/ProfilePage';
import { LoginPage } from '@pages/LoginPage';

test('Register new user via UI', async ({ page }) => {
    const profilePage = new ProfilePage(page);
    const uniqueUsername = `user_${Date.now().toString().slice(-6)}`;

    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials({
        firstname: 'John',
        lastname: 'Doe',
        address: '123 Main St',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: uniqueUsername,
        password: 'Password123!',
        confirmPassword: 'Password123!'
    });

    await profilePage.clickRegisterBtn();
    await expect(profilePage.welcomeMessage).toBeVisible();
});

test('Register with completely empty form', async ({ page }) => {
    const profilePage = new ProfilePage(page);

    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.clickRegisterBtn();

    await expect(profilePage.registerErrorMessages.first()).toBeVisible();
});

test('Password confirmation mismatch', async ({ page }) => {
    const profilePage = new ProfilePage(page);
    const uniqueUsername = `user_${Date.now().toString().slice(-6)}`;

    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials({
        firstname: 'John',
        lastname: 'Doe',
        address: '123 Main St',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: uniqueUsername,
        password: 'Password123!',
        confirmPassword: 'Password123456!'
    });

    await profilePage.clickRegisterBtn();
    await expect(profilePage.getErrorMessage('Passwords did not match.')).toBeVisible();
});

test('Duplicate username registration', async ({ page }) => {
    const profilePage = new ProfilePage(page);
    const duplicateUsername = `user_${Date.now().toString().slice(-6)}`;
    const userData = {
        firstname: 'John',
        lastname: 'Doe',
        address: '123 Main St',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: duplicateUsername,
        password: 'Password123!',
        confirmPassword: 'Password123!'
    };

    // 1. Initial registration
    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials(userData);
    await profilePage.clickRegisterBtn();
    await expect(profilePage.welcomeMessage).toBeVisible();

    // 2. Log out
    await page.getByRole('link', { name: 'Log Out' }).click();

    // 3. Attempt duplicate registration
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials(userData);
    await profilePage.clickRegisterBtn();

    // 4. Assert error
    await expect(profilePage.getErrorMessage('This username already exists.')).toBeVisible();
});

test('Login with freshly registered user', async ({ page }) => {
    const profilePage = new ProfilePage(page);
    const uniqueUsername = `user_${Date.now().toString().slice(-6)}`;
    const password = 'Password123!';

    // 1. Register new user
    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials({
        firstname: 'Zandro',
        lastname: 'Guinialope',
        address: '123 Main St',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: uniqueUsername,
        password: password,
        confirmPassword: password
    });
    await profilePage.clickRegisterBtn();
    await expect(profilePage.welcomeMessage).toBeVisible();

    // 2. Log out
    await page.getByRole('link', { name: 'Log Out' }).click();

    // 3. Log back in with freshly registered credentials
    const loginPage = new LoginPage(page);
    await loginPage.fillLoginCredentials(uniqueUsername, password);
    await loginPage.clickLoginBtn();

    // 4. Verify login successful
    await expect(loginPage.overviewHeading).toHaveText('Accounts Overview');
});

test('View Accounts Overview table', async ({ loginPage, page }) => {
    const profilePage = new ProfilePage(page);
    await expect(profilePage.accountColumnHeader).toBeVisible();
    await expect(profilePage.balanceColumnHeader).toBeVisible();
    await expect(profilePage.availableAmountColumnHeader).toBeVisible();
    await expect(profilePage.tableTotalAmount).toBeVisible();
});

test('TC-ACC-UI-002 Verify Total equals sum of balances', async ({ loginPage, page }) => {
    const profilePage = new ProfilePage(page);

    // 1) Parse all balance column values
    const balances = await profilePage.getAccountBalances();
    expect(balances.length).toBeGreaterThanOrEqual(1);

    // 2) Sum mathematically
    const calculatedSum = balances.reduce((sum, val) => sum + val, 0);

    // 3) Read Total row
    const reportedTotal = await profilePage.getTotalBalance();

    // Total matches sum of all individual balances within $0.01
    expect(reportedTotal).toBeCloseTo(calculatedSum, 2);
});
