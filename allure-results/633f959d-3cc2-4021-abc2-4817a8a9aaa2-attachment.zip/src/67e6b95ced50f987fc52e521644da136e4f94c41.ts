import {test, expect} from '@playwright/test';
import { AuthAPI } from '@api/AuthApi';

test.only('Authenticate with valid credentials', async({request}) =>{
    const authApi = new AuthAPI(request);
    const response = await authApi.login(process.env.TEST_USERNAME!,process.env.TEST_PASSWORD!);

    const responseBody = await response.json();
    console.log(responseBody)

    await expect(response.status()).toBe(200);
    await expect(responseBody.id).toEqual(12212);
    await expect(responseBody.firstName).toBe('John');
    await expect(responseBody.address.state).toBe('CA');

});

test('Validate login JSON response schema', async({request}) =>{
    const response = await request.get('https://parabank.parasoft.com/parabank/services/bank/login/john/demo', {
        headers: {
            'Accept': 'application/json'

        }

    });

    const responseBody = await response.json();
    
    await expect(response.status()).toBe(200);
    await expect(responseBody.id).toBeDefined();
    await expect(responseBody.firstName).toBeDefined();
    await expect(responseBody.lastName).toBeDefined();
    await expect(responseBody.address).toBeDefined();
    await expect(responseBody.phoneNumber).toBeDefined();
    await expect(responseBody.ssn).toBeDefined();

});

test('Validate response headers', async({request}) =>{
    const response = await request.get('')

});