import {test, expect} from '@playwright/test'
import { ProfilePage } from '@pages/ProfilePage'
import { profile } from 'console';


test('Register new user via UI', async({page}) =>{
    const profilePage = new ProfilePage(page);
    const uniqueUsername = `user_${Date.now().toString().slice(-6)}`;

    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials({
        firstname: 'John',
        lastname: 'Doe',
        address: '123 Main St',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: uniqueUsername,
        password: 'Password123!',
        confirmPassword: 'Password123!'
    });

    await profilePage.clickRegisterBtn();
    await expect(profilePage.welcomeMessage).toHaveText('Your account was created successfully. You are now logged in.')

});

test('Register with completely empty form', async({page}) =>{
    const profilePage = new ProfilePage(page);

    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.clickRegisterBtn();

    await expect(profilePage.registerErrorMessages.first()).toBeVisible();

});

test('Password confirmation mismatch', async({page}) =>{
    const profilePage = new ProfilePage(page);
    const uniqueUsername = `user_${Date.now().toString().slice(-6)}`;

    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials({
        firstname: 'John',
        lastname: 'Doe',
        address: '123MainSt',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: uniqueUsername,
        password: 'Password123!',
        confirmPassword: 'Password123456!'

    });

    await profilePage.clickRegisterBtn();

    await expect(profilePage.registerErrorMessages).toHaveText('Passwords did not match.');

});

test('Duplicate username registration', async({page}) =>{
    const profilePage = new ProfilePage(page);

    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials({
    
        firstname: 'John',
        lastname: 'Doe',
        address: '123 Main St',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: 'John',
        password: 'Password123!',
        confirmPassword: 'Password123!'

    });

    await profilePage.clickRegisterBtn();
  
    await expect(profilePage.registerErrorMessages).toHaveText('This username already exists.');

});

test('Login with freshly registered user', async({page}) =>{
    const profilePage = new ProfilePage(page);

    
    await profilePage.navigate();
    await profilePage.clickRegisterLink();
    await profilePage.fillRegisterCredentials({

    
        firstname: 'Zandro',
        lastname: 'Guinialope',
        address: '123 Main St',
        city: 'Beverly Hills',
        state: 'CA',
        zipCode: '90210',
        phone: '555-1234',
        ssn: '123-45-6789',
        username: 'Zandro',
        password: 'Password123!',
        confirmPassword: 'Password123!'



    });

    await profilePage.clickRegisterBtn();

    await expect(profilePage.welcomeMessage).toHaveText('Your account was created successfully. You are now logged in.');

});

