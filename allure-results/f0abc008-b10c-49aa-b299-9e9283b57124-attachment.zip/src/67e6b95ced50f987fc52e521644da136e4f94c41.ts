import {test, expect} from '@playwright/test'
import { AccountApi } from '@api/AccountApi'

test('Fetch accountsfor customer', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    
    expect(response.status()).toBe(200);
    
});

test.only('Validate account schema & data types', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    const responsebody = await response.json();

    console.log(responsebody);
    expect(responsebody[0].id).toBeDefined();
    expect(responsebody[0].customerId).toBeDefined();
    expect(responsebody[0].type).toBeDefined();
    expect(responsebody[0].balance).toBeDefined();


});