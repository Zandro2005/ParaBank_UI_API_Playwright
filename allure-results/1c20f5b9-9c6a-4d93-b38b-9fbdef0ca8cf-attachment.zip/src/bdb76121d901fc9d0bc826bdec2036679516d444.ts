import { test, expect } from '@fixtures/authFixture';
import { AccountsPage } from '@pages/AccountsPage';

test.describe('Accounts Overview UI', () => {

    test('TC-ACC-UI-001 View Accounts Overview table', async ({ loginPage, page }) => {
        const accountsPage = new AccountsPage(page);

        await expect(accountsPage.accountColumnHeader).toBeVisible();
        await expect(accountsPage.balanceColumnHeader).toBeVisible();
        await expect(accountsPage.availableAmountColumnHeader).toBeVisible();
        await expect(accountsPage.totalRow).toBeVisible();
    });

    test('TC-ACC-UI-002 Verify Total equals sum of balances', async ({ loginPage, page }) => {
        const accountsPage = new AccountsPage(page);

        // 1) Parse all balance column values
        const balances = await accountsPage.getAccountBalances();
        expect(balances.length).toBeGreaterThanOrEqual(1);

        // 2) Sum mathematically
        const calculatedSum = balances.reduce((sum, val) => sum + val, 0);

        // 3) Read Total row
        const reportedTotal = await accountsPage.getTotalBalance();

        // Total matches sum of all individual balances within $0.01
        expect(reportedTotal).toBeCloseTo(calculatedSum, 2);
    });

});
