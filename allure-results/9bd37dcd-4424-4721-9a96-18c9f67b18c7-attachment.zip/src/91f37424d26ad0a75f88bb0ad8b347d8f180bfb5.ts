import { APIRequestContext, APIResponse } from '@playwright/test';

export class TransferApi {
    readonly baseUrl = 'https://parabank.parasoft.com/parabank/services/bank';

    constructor(private request: APIRequestContext) {}

    /**
     * POST /transfer?fromAccountId={from}&toAccountId={to}&amount={amount}
     * Executes a fund transfer between accounts.
     */
    async transfer(
        fromAccountId?: number | string,
        toAccountId?: number | string,
        amount?: number | string,
        headers?: Record<string, string>
    ): Promise<APIResponse> {
        const params: Record<string, any> = {};
        if (fromAccountId !== undefined) params.fromAccountId = fromAccountId;
        if (toAccountId !== undefined) params.toAccountId = toAccountId;
        if (amount !== undefined) params.amount = amount;

        return await this.request.post(`${this.baseUrl}/transfer`, {
            params,
            headers: {
                'Accept': 'application/json',
                ...headers,
            },
        });
    }
}
