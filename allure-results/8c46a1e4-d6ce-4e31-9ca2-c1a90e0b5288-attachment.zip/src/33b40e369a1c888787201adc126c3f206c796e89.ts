import { Locator, Page } from '@playwright/test';

export class AccountsPage {
    readonly page: Page;
    readonly overviewTable: Locator;
    readonly accountRows: Locator;
    readonly balanceCells: Locator;
    readonly totalRow: Locator;
    readonly totalBalanceCell: Locator;
    readonly accountColumnHeader: Locator;
    readonly balanceColumnHeader: Locator;
    readonly availableAmountColumnHeader: Locator;
    
    // Open New Account elements
    readonly openNewAccountLink: Locator;
    readonly openNewAccountSubmitBtn: Locator;
    readonly accountType: Locator;
    readonly accountId: Locator;
    readonly accountHeading: Locator;
    readonly newAccountIdLink: Locator;

    constructor(page: Page) {
        this.page = page;
        this.overviewTable = page.locator('#accountTable');
        this.accountRows = page.locator('#accountTable tbody tr').filter({ has: page.locator('td a') });
        this.balanceCells = this.accountRows.locator('td:nth-child(2)');
        this.totalRow = page.locator('#accountTable tbody tr').filter({ hasText: 'Total' });
        this.totalBalanceCell = this.totalRow.locator('td:nth-child(2)');
        this.accountColumnHeader = page.getByRole('columnheader', { name: 'Account' });
        this.balanceColumnHeader = page.getByRole('columnheader', { name: 'Balance' });
        this.availableAmountColumnHeader = page.getByRole('columnheader', { name: 'Available Amount' });

        // Navigation link in left sidebar
        this.openNewAccountLink = page.getByRole('link', { name: 'Open New Account' });
        // Submit button on the form
        this.openNewAccountSubmitBtn = page.getByRole('button', { name: 'Open New Account' });
        this.accountType = page.locator('#type');
        this.accountId = page.locator('#fromAccountId');
        this.accountHeading = page.getByRole('heading', { name: 'Account Opened!' });
        this.newAccountIdLink = page.locator('#newAccountId');
    }

    async navigate(): Promise<void> {
        await this.page.goto('overview.htm');
        await this.overviewTable.waitFor({ state: 'visible' });
    }

    async getAccountBalances(): Promise<number[]> {
        await this.accountRows.first().waitFor({ state: 'visible' });
        const texts = await this.balanceCells.allInnerTexts();
        return texts.map(text => this.parseCurrency(text));
    }

    async getTotalBalance(): Promise<number> {
        await this.totalBalanceCell.waitFor({ state: 'visible' });
        const text = await this.totalBalanceCell.innerText();
        return this.parseCurrency(text);
    }

    parseCurrency(value: string): number {
        return parseFloat(value.replace(/[^0-9.-]+/g, ''));
    }

    async clickOpenNewAccountLink(): Promise<void> {
        await this.openNewAccountLink.click();
        await this.page.waitForURL('**/openaccount.htm');
        await this.accountId.waitFor({ state: 'visible' });
    }

    async selectAccountType(type: 'CHECKING' | 'SAVINGS' = 'CHECKING'): Promise<void> {
        await this.accountType.selectOption(type);
    }

    async selectAccountId(index: number = 0): Promise<void> {
        // Wait for accounts to be populated in the select dropdown
        await this.accountId.locator('option').first().waitFor({ state: 'attached' });
        await this.accountId.selectOption({ index });
    }

    async clickOpenNewAccountBtn(): Promise<void> {
        await this.openNewAccountSubmitBtn.click();
    }
}
