import {test, expect} from '@playwright/test'
import { AccountApi } from '@api/AccountApi'
import { AuthApi } from '@api/AuthApi';

test('Fetch accountsfor customer', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    
    expect(response.status()).toBe(200);
    
});

test('Validate account schema & data types', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getCustomerAccounts(12212);
    const responsebody = await response.json();

    expect(response.status()).toBe(200);
    expect(responsebody[0].id).toBeDefined();
    expect(responsebody[0].customerId).toBeDefined();
    expect(responsebody[0].type).toBeDefined();
    expect(responsebody[0].balance).toBeDefined();

});

test('Get account details by ID', async({request}) =>{
    const accountApi = new AccountApi(request);
    const response = await accountApi.getAccount(13344);
    const responsebody = await response.json()
    const requestId = responsebody.id;

    expect(response.status()).toBe(200);
    expect(responsebody.id).toEqual(requestId);
    

});

test('Verify customer account ownership', async({request}) =>{
    const accountApi = new AccountApi(request)
    const customerID = 12212; 
    const response = await accountApi.getCustomerAccounts(customerID);
    const responsebody = await response.json();

    expect(response.status()).toBe(200);
    expect(customerID).toEqual(responsebody[0].customerId);

});

test('Create CHECKING account via API', async({request}) =>{
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const accountType = 0;
    const accountId = 13344;
    const response = await accountApi.createAccount(customerId, accountType, accountId);
    const responsebody = await response.json()

    expect(response.status()).toBe(200);
    expect(responsebody.type).toBe('CHECKING');

});

test('Create SAVINGS account via API', async({request}) =>{
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const accountType = 1;
    const accountId = 13344;
    const response = await accountApi.createAccount(customerId, accountType, accountId);
    const responsebody = await response.json()

    expect(response.status()).toBe(200);
    expect(responsebody.type).toBe('SAVINGS');
    
});

test('Minimum opening deposit debit/credit', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const sourceAccountId = 13344;

    const initialSourceRes = await accountApi.getAccount(sourceAccountId);
    const initialBalance = (await initialSourceRes.json()).balance;

    const createRes = await accountApi.createAccount(customerId, 0, sourceAccountId);
    expect(createRes.status()).toBe(200);
    const createdAccount = await createRes.json();
    const newAccountId = createdAccount.id;

    const updatedSourceRes = await accountApi.getAccount(sourceAccountId);
    const updatedSourceBalance = (await updatedSourceRes.json()).balance;
    const newAccountRes = await accountApi.getAccount(newAccountId);
    const newAccountBalance = (await newAccountRes.json()).balance;

    expect(Math.abs(updatedSourceBalance - initialBalance)).toBe(100.00);

    expect(Math.abs(newAccountBalance)).toBe(100.00);
});

test('Newly created account in list', async ({ request }) => {
    const accountApi = new AccountApi(request);
    const customerId = 12212;
    const sourceAccountId = 13344;

    // 1. Create a new account (0 = CHECKING)
    const createRes = await accountApi.createAccount(customerId, 0, sourceAccountId);
    expect(createRes.status()).toBe(200);
    const newAccount = await createRes.json();
    const newAccountId = newAccount.id;

    // 2. Fetch all accounts for this customer: GET /customers/{id}/accounts
    const accountsRes = await accountApi.getCustomerAccounts(customerId);
    expect(accountsRes.status()).toBe(200);
    const accounts = await accountsRes.json();

    // 3. Verify new account ID is present in the customer's account list
    const isPresent = accounts.some((account: { id: number }) => account.id === newAccountId);
    expect(isPresent).toBe(true);
});
