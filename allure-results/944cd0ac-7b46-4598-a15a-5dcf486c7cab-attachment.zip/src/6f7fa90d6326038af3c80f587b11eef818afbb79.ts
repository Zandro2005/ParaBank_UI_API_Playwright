import { test, expect } from '@playwright/test';
import { TransferApi } from '@api/TransferApi';
import { AccountApi } from '@api/AccountApi';
import { TransactionApi } from '@api/TransactionApi';
import { transferTestData } from '@test-data/transfers';

// Run tests serially to prevent race conditions on account balances
test.describe.configure({ mode: 'serial' });

test.describe('2.3 Fund Transfer API Test Suite', () => {
    // Dynamically resolved test accounts belonging to customer 12212
    let sourceAccountId = 13122;
    let destAccountId = 13344;

    test.beforeAll(async ({ request }) => {
        try {
            const accountApi = new AccountApi(request);
            const res = await accountApi.getCustomerAccounts(12212);
            if (res.status() === 200) {
                const accounts = await res.json();
                if (Array.isArray(accounts)) {
                    const funded = accounts.filter((acc: any) => acc.balance > 100);
                    sourceAccountId = funded[0]?.id || 13122;
                    destAccountId = accounts.find((acc: any) => acc.id !== sourceAccountId && acc.balance >= 0)?.id || 13344;
                }
            }
        } catch {
            // Fallback to standard seeded accounts if network error occurs
            sourceAccountId = 13122;
            destAccountId = 13344;
        }
    });

    test.afterEach(async () => {
        // Pacing delay to avoid triggering Cloudflare Error 1015 rate limiting
        await new Promise(resolve => setTimeout(resolve, 300));
    });

    test('TC-TRF-API-001 Valid transfer between own accounts', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const amount = transferTestData.validAmount; // $50.00

        // 1. Send POST request to transfer funds from source to destination account
        const response = await transferApi.transfer(sourceAccountId, destAccountId, amount);

        // 2. Verify server responds with HTTP 200 OK
        expect(response.status()).toBe(200);

        // 3. Validate success confirmation text returned by ParaBank
        const responseText = await response.text();
        expect(responseText).toContain(`Successfully transferred $${amount}`);
        expect(responseText).toContain(`from account #${sourceAccountId} to account #${destAccountId}`);
    });

    test('TC-TRF-API-002 Source balance debit verification', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const accountApi = new AccountApi(request);
        const amount = transferTestData.smallAmount; // $10.00

        // 1. Query initial source account balance before the transfer
        const initialRes = await accountApi.getAccount(sourceAccountId);
        expect(initialRes.status()).toBe(200);
        const initialBalance = (await initialRes.json()).balance;

        // 2. Execute fund transfer
        const transferRes = await transferApi.transfer(sourceAccountId, destAccountId, amount);
        expect(transferRes.status()).toBe(200);

        // 3. Query updated source account balance
        const updatedRes = await accountApi.getAccount(sourceAccountId);
        expect(updatedRes.status()).toBe(200);
        const updatedBalance = (await updatedRes.json()).balance;

        // 4. Assert source balance is debited by exactly the transfer amount (S - X)
        expect(updatedBalance).toBeCloseTo(initialBalance - amount, 2);
    });

    test('TC-TRF-API-003 Destination balance credit verification', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const accountApi = new AccountApi(request);
        const amount = transferTestData.smallAmount; // $10.00

        // 1. Query initial destination account balance before the transfer
        const initialRes = await accountApi.getAccount(destAccountId);
        expect(initialRes.status()).toBe(200);
        const initialBalance = (await initialRes.json()).balance;

        // 2. Execute fund transfer
        const transferRes = await transferApi.transfer(sourceAccountId, destAccountId, amount);
        expect(transferRes.status()).toBe(200);

        // 3. Query updated destination account balance
        const updatedRes = await accountApi.getAccount(destAccountId);
        expect(updatedRes.status()).toBe(200);
        const updatedBalance = (await updatedRes.json()).balance;

        // 4. Assert destination balance is credited by exactly the transfer amount (D + X)
        expect(updatedBalance).toBeCloseTo(initialBalance + amount, 2);
    });

    test('TC-TRF-API-004 Conservation of total balances', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const accountApi = new AccountApi(request);
        const amount = 15.00;

        // 1. Record initial balances for both accounts and calculate total funds (S + D)
        const srcInitialRes = await accountApi.getAccount(sourceAccountId);
        const dstInitialRes = await accountApi.getAccount(destAccountId);
        const initialSrcBalance = (await srcInitialRes.json()).balance;
        const initialDstBalance = (await dstInitialRes.json()).balance;
        const totalBefore = initialSrcBalance + initialDstBalance;

        // 2. Execute the fund transfer
        const transferRes = await transferApi.transfer(sourceAccountId, destAccountId, amount);
        expect(transferRes.status()).toBe(200);

        // 3. Record post-transfer balances and calculate new total funds (S' + D')
        const srcUpdatedRes = await accountApi.getAccount(sourceAccountId);
        const dstUpdatedRes = await accountApi.getAccount(destAccountId);
        const updatedSrcBalance = (await srcUpdatedRes.json()).balance;
        const updatedDstBalance = (await dstUpdatedRes.json()).balance;
        const totalAfter = updatedSrcBalance + updatedDstBalance;

        // 4. Verify conservation of funds: total money before transfer must equal total after
        expect(totalAfter).toBeCloseTo(totalBefore, 2);
    });

    test('TC-TRF-API-005 Transfer with fractional cents amount', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const accountApi = new AccountApi(request);
        const amount = transferTestData.fractionalAmount; // $12.34

        // 1. Record initial source balance
        const initialRes = await accountApi.getAccount(sourceAccountId);
        const initialBalance = (await initialRes.json()).balance;

        // 2. Transfer fractional amount ($12.34)
        const response = await transferApi.transfer(sourceAccountId, destAccountId, amount);
        expect(response.status()).toBe(200);

        // 3. Verify balance is deducted cleanly without precision drift
        const updatedRes = await accountApi.getAccount(sourceAccountId);
        const updatedBalance = (await updatedRes.json()).balance;
        expect(updatedBalance).toBeCloseTo(initialBalance - amount, 2);
    });

    test('TC-TRF-API-006 Double-entry transaction creation', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const transactionApi = new TransactionApi(request);
        const amount = 25.00;

        // 1. Execute transfer
        const transferRes = await transferApi.transfer(sourceAccountId, destAccountId, amount);
        expect(transferRes.status()).toBe(200);

        // 2. Fetch transaction history for source account (A)
        const srcTxRes = await transactionApi.getAccountTransactions(sourceAccountId);
        expect(srcTxRes.status()).toBe(200);
        const srcTransactions = await srcTxRes.json();

        // 3. Fetch transaction history for destination account (B)
        const dstTxRes = await transactionApi.getAccountTransactions(destAccountId);
        expect(dstTxRes.status()).toBe(200);
        const dstTransactions = await dstTxRes.json();

        // 4. Confirm Account A has a Debit record ("Funds Transfer Sent")
        const debitEntry = srcTransactions.find(
            (tx: any) => tx.type === 'Debit' && tx.description === 'Funds Transfer Sent' && tx.amount === amount
        );
        expect(debitEntry).toBeDefined();

        // 5. Confirm Account B has a matching Credit record ("Funds Transfer Received")
        const creditEntry = dstTransactions.find(
            (tx: any) => tx.type === 'Credit' && tx.description === 'Funds Transfer Received' && tx.amount === amount
        );
        expect(creditEntry).toBeDefined();
    });

    test('TC-TRF-API-007 Transfer with zero amount', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. Attempt transfer with amount = 0
        const response = await transferApi.transfer(sourceAccountId, destAccountId, transferTestData.zeroAmount);

        // 2. Specification: Status 400 Bad Request. Log @known-defect if system accepts zero amount
        if (response.status() === 200) {
            test.info().annotations.push({
                type: 'known-defect',
                description: 'ParaBank accepts transfer with amount=0 instead of returning 400 Bad Request.',
            });
        }
        expect([400, 200]).toContain(response.status());
    });

    test('TC-TRF-API-008 Transfer with negative amount', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. Attempt transfer with negative amount (-$50)
        const response = await transferApi.transfer(sourceAccountId, destAccountId, transferTestData.negativeAmount);

        // 2. Specification: Status 400 Bad Request. Log @known-defect if system accepts negative transfer
        if (response.status() === 200) {
            test.info().annotations.push({
                type: 'known-defect',
                description: 'ParaBank accepts negative transfer amount (-$50) instead of returning 400 Bad Request.',
            });
        }
        expect([400, 200]).toContain(response.status());
    });

    test('TC-TRF-API-009 Transfer with empty amount parameter', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. Transfer with empty amount parameter (amount='')
        const response = await transferApi.transfer(sourceAccountId, destAccountId, '');

        // 2. Server must reject invalid parameter format (400 Bad Request or 500 error)
        expect([400, 500]).toContain(response.status());
    });

    test('TC-TRF-API-010 Transfer with non-numeric amount', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. Transfer with non-numeric amount string ('abc')
        const response = await transferApi.transfer(sourceAccountId, destAccountId, transferTestData.nonNumericAmount);

        // 2. Server must reject non-numeric parameter (400 Bad Request or 404 Route mismatch)
        expect([400, 404]).toContain(response.status());
    });

    test('TC-TRF-API-011 Transfer with invalid source account', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const invalidAccountId = transferTestData.invalidAccountId; // 999999999

        // 1. Attempt transfer using a non-existent source account ID
        const response = await transferApi.transfer(invalidAccountId, destAccountId, 50);

        // 2. Server must return HTTP 400 Bad Request
        expect(response.status()).toBe(400);

        // 3. Verify descriptive error message is returned
        const errorText = await response.text();
        expect(errorText).toContain('Could not find account');
        expect(errorText).toContain(`${invalidAccountId}`);
    });

    test('TC-TRF-API-012 Transfer with invalid destination account', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const accountApi = new AccountApi(request);
        const invalidAccountId = transferTestData.invalidAccountId; // 999999999

        // 1. Record initial source balance
        const initialRes = await accountApi.getAccount(sourceAccountId);
        const initialBalance = (await initialRes.json()).balance;

        // 2. Attempt transfer using a non-existent destination account ID
        const response = await transferApi.transfer(sourceAccountId, invalidAccountId, 50);

        // 3. Server must return HTTP 400 Bad Request
        expect(response.status()).toBe(400);

        // 4. Verify source account balance was not deducted
        const updatedRes = await accountApi.getAccount(sourceAccountId);
        const updatedBalance = (await updatedRes.json()).balance;
        expect(updatedBalance).toBeCloseTo(initialBalance, 2);
    });

    test('TC-TRF-API-013 Transfer from and to the same account', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. Attempt transfer where source and destination account are identical (A -> A)
        const response = await transferApi.transfer(sourceAccountId, sourceAccountId, 50);

        // 2. Specification: Status 400 Bad Request. Log @known-defect if system allows self-transfer
        if (response.status() === 200) {
            test.info().annotations.push({
                type: 'known-defect',
                description: 'ParaBank accepts transfer between identical source and destination accounts.',
            });
        }
        expect([400, 200]).toContain(response.status());
    });

    test('TC-TRF-API-014 Transfer exceeding available balance', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const accountApi = new AccountApi(request);

        // 1. Read current source balance
        const balanceRes = await accountApi.getAccount(sourceAccountId);
        const currentBalance = (await balanceRes.json()).balance;

        // 2. Attempt transfer exceeding the balance (S + 5000) as specified
        const overdraftAmount = currentBalance + 5000;
        const response = await transferApi.transfer(sourceAccountId, destAccountId, overdraftAmount);

        // 3. Specification: Rejected with 4xx. Balance unchanged. Log @known-defect if overdraft is permitted
        if (response.status() === 200) {
            test.info().annotations.push({
                type: 'known-defect',
                description: 'Overdraft defect: ParaBank allows fund transfers exceeding the source account balance.',
            });
        }
        expect([400, 403, 200]).toContain(response.status());
    });

    test('TC-TRF-API-015 Transfer missing query parameters', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. POST /transfer with no parameters supplied
        const response = await transferApi.transfer();

        // 2. Server must reject request due to missing arguments (400 Bad Request or 500 error)
        expect([400, 500]).toContain(response.status());
    });

    test('TC-TRF-API-016 Transfer with excessive decimal places', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const amountWith3Decimals = transferTestData.excessiveDecimalsAmount; // 10.999

        // 1. Attempt transfer with 3 decimal places
        const response = await transferApi.transfer(sourceAccountId, destAccountId, amountWith3Decimals);

        // 2. Specification: Rejected (4xx/500) or rounded cleanly to 2 decimals
        if (response.status() === 200) {
            test.info().annotations.push({
                type: 'known-defect',
                description: 'ParaBank accepted transfer with 3 decimal places without input validation.',
            });
            expect(response.status()).toBe(200);
        } else {
            // Server rejected the excessive decimals (400 Bad Request or 500 Format Error)
            expect([400, 422, 500]).toContain(response.status());
        }

        // Reset database to ensure 3-decimal test does not affect subsequent tests
        await request.post('https://parabank.parasoft.com/parabank/services/bank/initializeDB');
    });

    test('TC-TRF-API-017 Transfer from another customer\'s account', async ({ request }) => {
        const transferApi = new TransferApi(request);
        const foreignAccountId = 999999999; // Non-owned foreign account ID

        // 1. Attempt to initiate transfer from an account not owned by customer 12212
        const response = await transferApi.transfer(foreignAccountId, destAccountId, 50);

        // 2. Specification: Status 403 Forbidden / 400. Log @known-defect if IDOR vulnerability exists
        if (response.status() === 200) {
            test.info().annotations.push({
                type: 'known-defect',
                description: 'IDOR Defect: Transfer endpoint allows initiating transfer from unowned account without authorization check.',
            });
        }
        expect([400, 403, 404, 500, 200]).toContain(response.status());
    });

    test('TC-TRF-API-018 Unauthorized transfer request', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. Send transfer request without authentication credentials or session cookie
        const response = await transferApi.transfer(sourceAccountId, destAccountId, 50);

        // 2. Specification: Status 401 Unauthorized. Log @known-defect if public demo endpoint is unsecured
        if (response.status() === 200) {
            test.info().annotations.push({
                type: 'known-defect',
                description: 'ParaBank REST API endpoints do not require authentication or session validation.',
            });
        }
        expect([401, 403, 200]).toContain(response.status());
    });

    test('TC-TRF-API-019 Transfer response SLA', async ({ request }) => {
        const transferApi = new TransferApi(request);

        // 1. Measure latency of the transfer API call
        const startTime = performance.now();
        const response = await transferApi.transfer(sourceAccountId, destAccountId, 10);
        const duration = performance.now() - startTime;

        // 2. Confirm HTTP 200 OK
        expect(response.status()).toBe(200);

        // 3. Confirm response time satisfies performance SLA (< 2000 ms)
        expect(duration).toBeLessThan(2000);
    });
});
